CREATE TABLE "Reviews_Summary"(
   listing_id INT,
   date DATE
);