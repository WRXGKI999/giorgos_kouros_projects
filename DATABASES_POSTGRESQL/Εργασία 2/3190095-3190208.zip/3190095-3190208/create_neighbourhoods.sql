CREATE TABLE "Neighbourhoods"(
   neighbourhood_group VARCHAR(10),
   neighbourhood VARCHAR(40),
   PRIMARY KEY (neighbourhood)
);