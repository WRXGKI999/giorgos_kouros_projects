ALTER TABLE "Listings2" RENAME TO "Listing2";
ALTER TABLE "Listings_Summary2" RENAME TO "Listing_Summary2";
ALTER TABLE "Reviews2" RENAME TO "Review2";
ALTER TABLE "Reviews_Summary2" RENAME TO "Review_Summary2";
ALTER TABLE "Neighbourhoods2" RENAME TO "Neighbourhood2";